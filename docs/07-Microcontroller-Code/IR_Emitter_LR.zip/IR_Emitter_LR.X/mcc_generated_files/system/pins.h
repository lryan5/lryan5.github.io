/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA0 aliases
#define IO_RA0_TRIS                 TRISAbits.TRISA0
#define IO_RA0_LAT                  LATAbits.LATA0
#define IO_RA0_PORT                 PORTAbits.RA0
#define IO_RA0_WPU                  WPUAbits.WPUA0
#define IO_RA0_OD                   ODCONAbits.ODCA0
#define IO_RA0_ANS                  ANSELAbits.ANSELA0
#define IO_RA0_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define IO_RA0_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define IO_RA0_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define IO_RA0_GetValue()           PORTAbits.RA0
#define IO_RA0_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define IO_RA0_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define IO_RA0_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define IO_RA0_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define IO_RA0_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define IO_RA0_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define IO_RA0_SetAnalogMode()      do { ANSELAbits.ANSELA0 = 1; } while(0)
#define IO_RA0_SetDigitalMode()     do { ANSELAbits.ANSELA0 = 0; } while(0)

// get/set RA4 aliases
#define Red_LED_TRIS                 TRISAbits.TRISA4
#define Red_LED_LAT                  LATAbits.LATA4
#define Red_LED_PORT                 PORTAbits.RA4
#define Red_LED_WPU                  WPUAbits.WPUA4
#define Red_LED_OD                   ODCONAbits.ODCA4
#define Red_LED_ANS                  ANSELAbits.ANSELA4
#define Red_LED_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define Red_LED_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define Red_LED_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define Red_LED_GetValue()           PORTAbits.RA4
#define Red_LED_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define Red_LED_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)
#define Red_LED_SetPullup()          do { WPUAbits.WPUA4 = 1; } while(0)
#define Red_LED_ResetPullup()        do { WPUAbits.WPUA4 = 0; } while(0)
#define Red_LED_SetPushPull()        do { ODCONAbits.ODCA4 = 0; } while(0)
#define Red_LED_SetOpenDrain()       do { ODCONAbits.ODCA4 = 1; } while(0)
#define Red_LED_SetAnalogMode()      do { ANSELAbits.ANSELA4 = 1; } while(0)
#define Red_LED_SetDigitalMode()     do { ANSELAbits.ANSELA4 = 0; } while(0)

// get/set RB5 aliases
#define SPKR_DIG_OUT_TRIS                 TRISBbits.TRISB5
#define SPKR_DIG_OUT_LAT                  LATBbits.LATB5
#define SPKR_DIG_OUT_PORT                 PORTBbits.RB5
#define SPKR_DIG_OUT_WPU                  WPUBbits.WPUB5
#define SPKR_DIG_OUT_OD                   ODCONBbits.ODCB5
#define SPKR_DIG_OUT_ANS                  ANSELBbits.ANSELB5
#define SPKR_DIG_OUT_SetHigh()            do { LATBbits.LATB5 = 1; } while(0)
#define SPKR_DIG_OUT_SetLow()             do { LATBbits.LATB5 = 0; } while(0)
#define SPKR_DIG_OUT_Toggle()             do { LATBbits.LATB5 = ~LATBbits.LATB5; } while(0)
#define SPKR_DIG_OUT_GetValue()           PORTBbits.RB5
#define SPKR_DIG_OUT_SetDigitalInput()    do { TRISBbits.TRISB5 = 1; } while(0)
#define SPKR_DIG_OUT_SetDigitalOutput()   do { TRISBbits.TRISB5 = 0; } while(0)
#define SPKR_DIG_OUT_SetPullup()          do { WPUBbits.WPUB5 = 1; } while(0)
#define SPKR_DIG_OUT_ResetPullup()        do { WPUBbits.WPUB5 = 0; } while(0)
#define SPKR_DIG_OUT_SetPushPull()        do { ODCONBbits.ODCB5 = 0; } while(0)
#define SPKR_DIG_OUT_SetOpenDrain()       do { ODCONBbits.ODCB5 = 1; } while(0)
#define SPKR_DIG_OUT_SetAnalogMode()      do { ANSELBbits.ANSELB5 = 1; } while(0)
#define SPKR_DIG_OUT_SetDigitalMode()     do { ANSELBbits.ANSELB5 = 0; } while(0)

// get/set RC7 aliases
#define Green_LED_TRIS                 TRISCbits.TRISC7
#define Green_LED_LAT                  LATCbits.LATC7
#define Green_LED_PORT                 PORTCbits.RC7
#define Green_LED_WPU                  WPUCbits.WPUC7
#define Green_LED_OD                   ODCONCbits.ODCC7
#define Green_LED_ANS                  ANSELCbits.ANSELC7
#define Green_LED_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define Green_LED_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define Green_LED_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define Green_LED_GetValue()           PORTCbits.RC7
#define Green_LED_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define Green_LED_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define Green_LED_SetPullup()          do { WPUCbits.WPUC7 = 1; } while(0)
#define Green_LED_ResetPullup()        do { WPUCbits.WPUC7 = 0; } while(0)
#define Green_LED_SetPushPull()        do { ODCONCbits.ODCC7 = 0; } while(0)
#define Green_LED_SetOpenDrain()       do { ODCONCbits.ODCC7 = 1; } while(0)
#define Green_LED_SetAnalogMode()      do { ANSELCbits.ANSELC7 = 1; } while(0)
#define Green_LED_SetDigitalMode()     do { ANSELCbits.ANSELC7 = 0; } while(0)

// get/set RD0 aliases
#define Test_LED_TRIS                 TRISDbits.TRISD0
#define Test_LED_LAT                  LATDbits.LATD0
#define Test_LED_PORT                 PORTDbits.RD0
#define Test_LED_WPU                  WPUDbits.WPUD0
#define Test_LED_OD                   ODCONDbits.ODCD0
#define Test_LED_ANS                  ANSELDbits.ANSELD0
#define Test_LED_SetHigh()            do { LATDbits.LATD0 = 1; } while(0)
#define Test_LED_SetLow()             do { LATDbits.LATD0 = 0; } while(0)
#define Test_LED_Toggle()             do { LATDbits.LATD0 = ~LATDbits.LATD0; } while(0)
#define Test_LED_GetValue()           PORTDbits.RD0
#define Test_LED_SetDigitalInput()    do { TRISDbits.TRISD0 = 1; } while(0)
#define Test_LED_SetDigitalOutput()   do { TRISDbits.TRISD0 = 0; } while(0)
#define Test_LED_SetPullup()          do { WPUDbits.WPUD0 = 1; } while(0)
#define Test_LED_ResetPullup()        do { WPUDbits.WPUD0 = 0; } while(0)
#define Test_LED_SetPushPull()        do { ODCONDbits.ODCD0 = 0; } while(0)
#define Test_LED_SetOpenDrain()       do { ODCONDbits.ODCD0 = 1; } while(0)
#define Test_LED_SetAnalogMode()      do { ANSELDbits.ANSELD0 = 1; } while(0)
#define Test_LED_SetDigitalMode()     do { ANSELDbits.ANSELD0 = 0; } while(0)

// get/set RD6 aliases
#define MTR_DIG_OUT_TRIS                 TRISDbits.TRISD6
#define MTR_DIG_OUT_LAT                  LATDbits.LATD6
#define MTR_DIG_OUT_PORT                 PORTDbits.RD6
#define MTR_DIG_OUT_WPU                  WPUDbits.WPUD6
#define MTR_DIG_OUT_OD                   ODCONDbits.ODCD6
#define MTR_DIG_OUT_ANS                  ANSELDbits.ANSELD6
#define MTR_DIG_OUT_SetHigh()            do { LATDbits.LATD6 = 1; } while(0)
#define MTR_DIG_OUT_SetLow()             do { LATDbits.LATD6 = 0; } while(0)
#define MTR_DIG_OUT_Toggle()             do { LATDbits.LATD6 = ~LATDbits.LATD6; } while(0)
#define MTR_DIG_OUT_GetValue()           PORTDbits.RD6
#define MTR_DIG_OUT_SetDigitalInput()    do { TRISDbits.TRISD6 = 1; } while(0)
#define MTR_DIG_OUT_SetDigitalOutput()   do { TRISDbits.TRISD6 = 0; } while(0)
#define MTR_DIG_OUT_SetPullup()          do { WPUDbits.WPUD6 = 1; } while(0)
#define MTR_DIG_OUT_ResetPullup()        do { WPUDbits.WPUD6 = 0; } while(0)
#define MTR_DIG_OUT_SetPushPull()        do { ODCONDbits.ODCD6 = 0; } while(0)
#define MTR_DIG_OUT_SetOpenDrain()       do { ODCONDbits.ODCD6 = 1; } while(0)
#define MTR_DIG_OUT_SetAnalogMode()      do { ANSELDbits.ANSELD6 = 1; } while(0)
#define MTR_DIG_OUT_SetDigitalMode()     do { ANSELDbits.ANSELD6 = 0; } while(0)

// get/set RE2 aliases
#define Blue_LED_TRIS                 TRISEbits.TRISE2
#define Blue_LED_LAT                  LATEbits.LATE2
#define Blue_LED_PORT                 PORTEbits.RE2
#define Blue_LED_WPU                  WPUEbits.WPUE2
#define Blue_LED_OD                   ODCONEbits.ODCE2
#define Blue_LED_ANS                  ANSELEbits.ANSELE2
#define Blue_LED_SetHigh()            do { LATEbits.LATE2 = 1; } while(0)
#define Blue_LED_SetLow()             do { LATEbits.LATE2 = 0; } while(0)
#define Blue_LED_Toggle()             do { LATEbits.LATE2 = ~LATEbits.LATE2; } while(0)
#define Blue_LED_GetValue()           PORTEbits.RE2
#define Blue_LED_SetDigitalInput()    do { TRISEbits.TRISE2 = 1; } while(0)
#define Blue_LED_SetDigitalOutput()   do { TRISEbits.TRISE2 = 0; } while(0)
#define Blue_LED_SetPullup()          do { WPUEbits.WPUE2 = 1; } while(0)
#define Blue_LED_ResetPullup()        do { WPUEbits.WPUE2 = 0; } while(0)
#define Blue_LED_SetPushPull()        do { ODCONEbits.ODCE2 = 0; } while(0)
#define Blue_LED_SetOpenDrain()       do { ODCONEbits.ODCE2 = 1; } while(0)
#define Blue_LED_SetAnalogMode()      do { ANSELEbits.ANSELE2 = 1; } while(0)
#define Blue_LED_SetDigitalMode()     do { ANSELEbits.ANSELE2 = 0; } while(0)

// get/set RF0 aliases
#define RF0_TRIS                 TRISFbits.TRISF0
#define RF0_LAT                  LATFbits.LATF0
#define RF0_PORT                 PORTFbits.RF0
#define RF0_WPU                  WPUFbits.WPUF0
#define RF0_OD                   ODCONFbits.ODCF0
#define RF0_ANS                  ANSELFbits.ANSELF0
#define RF0_SetHigh()            do { LATFbits.LATF0 = 1; } while(0)
#define RF0_SetLow()             do { LATFbits.LATF0 = 0; } while(0)
#define RF0_Toggle()             do { LATFbits.LATF0 = ~LATFbits.LATF0; } while(0)
#define RF0_GetValue()           PORTFbits.RF0
#define RF0_SetDigitalInput()    do { TRISFbits.TRISF0 = 1; } while(0)
#define RF0_SetDigitalOutput()   do { TRISFbits.TRISF0 = 0; } while(0)
#define RF0_SetPullup()          do { WPUFbits.WPUF0 = 1; } while(0)
#define RF0_ResetPullup()        do { WPUFbits.WPUF0 = 0; } while(0)
#define RF0_SetPushPull()        do { ODCONFbits.ODCF0 = 0; } while(0)
#define RF0_SetOpenDrain()       do { ODCONFbits.ODCF0 = 1; } while(0)
#define RF0_SetAnalogMode()      do { ANSELFbits.ANSELF0 = 1; } while(0)
#define RF0_SetDigitalMode()     do { ANSELFbits.ANSELF0 = 0; } while(0)

// get/set RF1 aliases
#define RF1_TRIS                 TRISFbits.TRISF1
#define RF1_LAT                  LATFbits.LATF1
#define RF1_PORT                 PORTFbits.RF1
#define RF1_WPU                  WPUFbits.WPUF1
#define RF1_OD                   ODCONFbits.ODCF1
#define RF1_ANS                  ANSELFbits.ANSELF1
#define RF1_SetHigh()            do { LATFbits.LATF1 = 1; } while(0)
#define RF1_SetLow()             do { LATFbits.LATF1 = 0; } while(0)
#define RF1_Toggle()             do { LATFbits.LATF1 = ~LATFbits.LATF1; } while(0)
#define RF1_GetValue()           PORTFbits.RF1
#define RF1_SetDigitalInput()    do { TRISFbits.TRISF1 = 1; } while(0)
#define RF1_SetDigitalOutput()   do { TRISFbits.TRISF1 = 0; } while(0)
#define RF1_SetPullup()          do { WPUFbits.WPUF1 = 1; } while(0)
#define RF1_ResetPullup()        do { WPUFbits.WPUF1 = 0; } while(0)
#define RF1_SetPushPull()        do { ODCONFbits.ODCF1 = 0; } while(0)
#define RF1_SetOpenDrain()       do { ODCONFbits.ODCF1 = 1; } while(0)
#define RF1_SetAnalogMode()      do { ANSELFbits.ANSELF1 = 1; } while(0)
#define RF1_SetDigitalMode()     do { ANSELFbits.ANSELF1 = 0; } while(0)

// get/set RF7 aliases
#define WGT_DIG_IN_TRIS                 TRISFbits.TRISF7
#define WGT_DIG_IN_LAT                  LATFbits.LATF7
#define WGT_DIG_IN_PORT                 PORTFbits.RF7
#define WGT_DIG_IN_WPU                  WPUFbits.WPUF7
#define WGT_DIG_IN_OD                   ODCONFbits.ODCF7
#define WGT_DIG_IN_ANS                  ANSELFbits.ANSELF7
#define WGT_DIG_IN_SetHigh()            do { LATFbits.LATF7 = 1; } while(0)
#define WGT_DIG_IN_SetLow()             do { LATFbits.LATF7 = 0; } while(0)
#define WGT_DIG_IN_Toggle()             do { LATFbits.LATF7 = ~LATFbits.LATF7; } while(0)
#define WGT_DIG_IN_GetValue()           PORTFbits.RF7
#define WGT_DIG_IN_SetDigitalInput()    do { TRISFbits.TRISF7 = 1; } while(0)
#define WGT_DIG_IN_SetDigitalOutput()   do { TRISFbits.TRISF7 = 0; } while(0)
#define WGT_DIG_IN_SetPullup()          do { WPUFbits.WPUF7 = 1; } while(0)
#define WGT_DIG_IN_ResetPullup()        do { WPUFbits.WPUF7 = 0; } while(0)
#define WGT_DIG_IN_SetPushPull()        do { ODCONFbits.ODCF7 = 0; } while(0)
#define WGT_DIG_IN_SetOpenDrain()       do { ODCONFbits.ODCF7 = 1; } while(0)
#define WGT_DIG_IN_SetAnalogMode()      do { ANSELFbits.ANSELF7 = 1; } while(0)
#define WGT_DIG_IN_SetDigitalMode()     do { ANSELFbits.ANSELF7 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/