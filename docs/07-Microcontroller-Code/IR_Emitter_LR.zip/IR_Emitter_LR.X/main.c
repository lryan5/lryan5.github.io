 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include "stdio.h"
/*
    Main application
*/

int main(void)
{
    volatile uint8_t rxchar; // initializes rxchar
    volatile uint16_t adcCheck;
    void ADC_Enable(void);
    SYSTEM_Initialize(); // Initializes everything
    ADC_Initialize();
    ADC_ChannelSelect(ADC_CHANNEL_ANA0);
    //UART1_Initialize(void);
   
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts 
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global Interrupts 
    // Use the following macros to: 

    // Enable the Global Interrupts 
    //INTERRUPT_GlobalInterruptEnable(); 

    // Disable the Global Interrupts 
    //INTERRUPT_GlobalInterruptDisable(); 


    while(1)
    {
       // printf("\n\rGo ASU!\n\r"); // Prints Go ASU! on new line
        ADC_ConversionStart();
        adcCheck = ADC_ConversionResultGet();
        printf("\n\r ADC Value %d", adcCheck);
        //sprintf("\n\r", WGT_DIG_IN_GetValue());
        __delay_ms(10);
        
        Green_LED_SetHigh();
                
        if (adcCheck >= 500)//500 for class one
        {
            Blue_LED_SetLow();
            Test_LED_SetLow();
            MTR_DIG_OUT_SetHigh();
            SPKR_DIG_OUT_SetLow();
            
            __delay_ms(10);
            
        }
        if (adcCheck < 500)//500 for class one
        {
           Test_LED_SetHigh();
           Blue_LED_SetHigh();
           MTR_DIG_OUT_SetLow();
           SPKR_DIG_OUT_SetHigh();
            __delay_ms(10);
            
        }
        
        if (WGT_DIG_IN_GetValue() == HIGH)
        {
            Red_LED_SetLow();
             __delay_ms(10);
        }
        if (WGT_DIG_IN_GetValue() == LOW)
        {
            Red_LED_SetHigh();
             __delay_ms(10);
        }
        
        /*if (UART1_IsRxReady()) //checks if Rx is ready
        {
            rxchar = UART1_Read(); // Reads Rx
            //semicolon = UART1_Read();
            
            if (UART1_IsTxReady()) // Checks if Tx is ready
            {
                
               
                
                UART1_Write(adcCheck); // Writes character
                //UART1_Write(Button);
                //LED0_Toggle();  // Toggles LED
                
                
                
            }
        }*/
        }
    }    
