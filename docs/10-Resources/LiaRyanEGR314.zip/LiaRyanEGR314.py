from machine import UART, Pin
import my_oled
import uasyncio as asyncio
from time import sleep
import time

# -------------------------
# Config
# -------------------------
MY_ID       = b'L'
TEAM        = [b'M', b'C', b'A', b'L', b'V', b'K',b'X']

MAX_MSG_LEN = 32
SEND_INTERVAL_MS = 2000  # max send rate — change via this one variable

# -------------------------
# Hardware
# -------------------------
uart = UART(1, 9600, tx=17, rx=18)
uart.init(9600, bits=8, parity=None, stop=1)

REDLED   = Pin(36, Pin.OUT)
GREENLED = Pin(37, Pin.OUT)
Button = Pin(8, Pin.IN, Pin.PULL_UP)
ROW_PINS = [Pin(p, Pin.OUT) for p in [10, 21, 14, 12]]   
COL_PINS = [Pin(p, Pin.IN, Pin.PULL_DOWN) for p in [11, 9, 13]]  

KEYS = [
    ['1', '2', '3'],
    ['4', '5', '6'],
    ['1', '2', '3'],
    ['*', '0', '#'],
]

def wrap_text(text, max_chars=16):
    """Split text into lines of max_chars width."""
    lines = []
    while len(text) > max_chars:
        lines.append(text[:max_chars])
        text = text[max_chars:]
    lines.append(text)
    return lines

def display_wrapped(text, char_height=10):
    my_oled.oled.fill(0)
    lines = wrap_text(text)
    for i, line in enumerate(lines):
        my_oled.print_text(line, 0, i * char_height)
    my_oled.oled.show()

def scan_keypad():
    """Returns the key character pressed, or None."""
    for r, row_pin in enumerate(ROW_PINS):
        row_pin.value(1)
        for c, col_pin in enumerate(COL_PINS):
            if col_pin.value() == 1:
                row_pin.value(0)
                return KEYS[r][c]
        row_pin.value(0)
    return None


# Startup blink
REDLED.value(1); sleep(0.3); REDLED.value(0)
GREENLED.value(1); sleep(0.3); GREENLED.value(0)

# -------------------------
# Message Parsing
# -------------------------
def parse_message(msg):
    try:
        if not msg.startswith(b'AZ') or not msg.endswith(b'YB'):
            return None, "FORMAT_ERROR"

        core = msg[2:-2]          # strip AZ / YB

        if len(core) < 2:
            return None, "FORMAT_ERROR"

        src  = core[0:1]
        dest = core[1:2]
        body = core[2:]

        if len(body) > MAX_MSG_LEN:
            return None, "TOO_LONG"

#         if src == MY_ID:
#             return None, "FROM_SELF"

        if src not in TEAM:
            return None, "UNKNOWN_SENDER"

        return (src, dest, body), None

    except Exception:
        return None, "PARSE_FAIL"

# -------------------------
# Message Builder
# -------------------------
def build_message(dest_id, body_YBtes):
#     if len(body_YBtes) > MAX_MSG_LEN:
#         raise ValueError("Body too long")
    if b'AZ' in body_YBtes or b'YB' in body_YBtes:
        raise ValueError("Body contains framing YBtes")
    return b'AZ' + MY_ID + dest_id + body_YBtes + b'YB'

# -------------------------
# Handle messages meant for me
# -------------------------
def handle_my_message(src, body):
    try:
        text = body.decode()
        senderID = src.decode()
    except:
        text = str(body)
        senderID = str(src)
    print("Message:", text)
    if src == b'V':
            my_oled.print_text(text, 0, 12)
            my_oled.oled.show()
#     my_oled.oled.fill(0)
    else:
        display_wrapped(text)
        my_oled.oled.show()
    GREENLED.value(1)
    sleep(0.2)
    GREENLED.value(0)
#     my_oled.oled.fill(0)

# -------------------------
# UART Receiver 
# -------------------------
async def receiver():
    buffer = b''
    sreader = asyncio.StreamReader(uart)
    print("[RX] Receiver started")

    while True:
        YBte = await sreader.read(1)
        if not YBte:
            continue

        buffer += YBte

        # Overflow guard
#         if len(buffer) > MAX_MSG_LEN + 10:
#             print("[RX] Buffer overflow — discarding")
#             buffer = b''
#             continue

        if buffer.endswith(b'YB'):
            print("[RX] Raw:", buffer)

            parsed, error = parse_message(buffer)
            buffer = b''

            if error:
                print("[RX] Error:", error)
                REDLED.value(1)
                await asyncio.sleep_ms(200)
                REDLED.value(0)
                continue

            src, dest, body = parsed

            if dest == MY_ID or dest == b'X':
                handle_my_message(src, body)

            elif dest in TEAM:
                forwarded = b'AZ' + src + dest + body + b'YB'
                uart.write(forwarded)
                print(f"[TX] Forwarded to {dest.decode()}: {forwarded}")

            else:
                print("[RX] Unknown destination — dropping")

# -------------------------
# UART Sender (async)
# -------------------------
async def sender():
    print("[TX] Sender started")
    counter = 0
    last_key = None

    while True:
        key = scan_keypad()

        if key is not None and key != last_key:  # new keypress
            dest_id = b'L'
            dest_id2 = b'K'
            body = f"{key}".encode()

            try:
                pkt = build_message(dest_id, body)
                pkt2 = build_message(dest_id2, body)
                uart.write(pkt)
                uart.write(pkt2)
                print(f"[TX] Sent key '{key}':", pkt)
                print(f"[TX] Sent key '{key}':", pkt2)
                counter = (counter + 1) % 10000
            except ValueError as e:
                print("[TX] Build error:", e)

        last_key = key
        await asyncio.sleep_ms(50)

# -------------------------
# Entry point
# -------------------------
async def main():
    await asyncio.gather(
        receiver(),
        sender(),
    )

asyncio.run(main())
